# RED BUS — Maputo & Katembe

Protótipo navegável criado a partir do PDF de requisitos fornecido e da análise prévia do City Sightseeing. A identidade, a composição e os textos foram preparados para Maputo; fotografias fornecidas pelo utilizador. O símbolo tipográfico e o ícone de autocarro são propostas visuais, não um logótipo oficial aprovado.

## Executar

```sh
npm run dev
```

O servidor local é apenas um ambiente de QA: usa uma identidade fictícia e dados em .preview/, ignorados pelo Git. Não deve ser usado como servidor de produção. O código desse servidor nunca entra no Worker publicado.

```sh
npm run build
npm test
```

A compilação inclui os recursos de public/ num Worker ES module em dist/server/index.js. O alojamento usa a ligação R2 BUCKET e a variável secreta ADMIN_EMAIL. A autenticação é fornecida pelo Sites/ChatGPT; não existem palavras-passe administrativas guardadas no código.

## Implementado nesta versão

- Página turística responsiva, identidade vermelha, creme e verde escuro, galeria das três fotografias.
- Textos principais e reserva em português e inglês; alguns nomes e rótulos administrativos permanecem em português.
- Mapa topográfico real de Maputo e Katembe com Leaflet 1.9.4 e OpenTopoMap (dados OpenStreetMap/SRTM), navegação e escala; sem rotas, linhas ou paragens inventadas. A cartografia requer internet. As duas opções de passeio da reserva continuam a ser uma simulação comercial, sem traçado geográfico aprovado.
- Seis preços iniciais do PDF. Reserva simulada para adultos, crianças 6–12 e menores de 6.
- Reserva em três etapas, calendário sexta/sábado/domingo, datas especiais e bloqueadas configuráveis.
- Passageiros, preço calculado, capacidade local e verificação antes da emissão.
- Bilhete de teste com identificador aleatório, QR real que codifica o endereço de validação, impressão/guardar PDF pelo navegador.
- Histórico local, cancelamento de bilhetes ainda não utilizados e libertação da lotação local.
- Gestão de demonstração: preços, capacidade, horários, datas extraordinárias, registo local de actividade e exportação CSV.
- Validação única por bilhete neste navegador. A repetição é rejeitada.
- Manifesto e service worker para instalação web e cache dos recursos locais após a primeira visita bem-sucedida.

## Não é um sistema de produção

O CMS tem autenticação e autorização de Admin no servidor, publicação persistente e carregamento de imagens. A venda de bilhetes continua a ser uma demonstração: não existem servidor de reservas, contas de passageiros, base de dados partilhada de reservas, pagamentos reais, comprovativos fiscais, emails, SMS, WhatsApp, reembolsos, GPS ou sincronização entre dispositivos. O controlo local não evita concorrência real entre separadores ou dispositivos. O estado local pode ser alterado pelo utilizador. O QR não é uma credencial segura de embarque: é um endereço com identificador de demonstração. Não há bloqueio temporário de inventário durante pagamento, assinatura criptográfica de bilhetes nem reconciliação financeira.

A área antiga de simulação operacional continua aberta e identificada como demonstração. A nova área /admin é separada e só permite publicar conteúdo à conta autorizada. Não usar dados pessoais reais. Não apresentar pagamentos simulados como receita efectiva. O leitor de QR deve abrir o mesmo endereço e o mesmo navegador que contém os bilhetes de teste; em outro dispositivo, os dados não estarão presentes.

A cache offline inclui recursos locais. As fontes do Google têm alternativas do sistema e não são garantidas offline. A instalação PWA e o funcionamento offline não foram testados em aparelhos Android/iOS físicos. A apresentação foi verificada no navegador de computador; a adaptação móvel foi implementada em CSS, sem validação visual em aparelho físico.

## Dados a confirmar com o operador

Capacidade real; horários; rotas/paragens aprovadas; contactos; composição familiar; mínimo de grupo; benefícios premium; política de cancelamento; acessibilidade física; domínio; logótipo oficial; parceiros de pagamento. A lotação 60, as partidas 09:00/12:00/15:00 e o embarque central são exemplos configuráveis, não informações operacionais confirmadas. Cada criança conta como passageiro na simulação.

O PDF refere 05/11/2026 e 10/11/2026. À data de desenvolvimento, 17/11/2026, esses marcos já passaram. É necessário reprogramar o lançamento comercial; a página não anuncia datas antigas como futuras.

## Testes realizados em 17/11/2026

1. Validação sintáctica de app.js e sw.js com node --check: aprovada.
2. Navegação e carregamento da página em navegador: verificados.
3. Reserva de 1 adulto + 1 criança: total de teste 2.250 MT; emissão com nomes e QR verificada.
4. Primeira validação aceite; segunda validação rejeitada.
5. Capacidade reduzida para 2 com 2 passageiros emitidos: disponibilidade 0; nova reserva bloqueada.
6. Configuração de capacidade guardada e restaurada para 60.
7. Alternância para inglês: conteúdos principais verificados.

Os dados desta verificação existem apenas no navegador de QA e não são distribuídos no código.

## Evolução recomendada

1. Confirmar dados comerciais, percursos e políticas; aprovar identidade e interface.
2. Implementar API e base de dados transaccional: contas, funções de acesso, viagens, inventário, reservas e auditoria persistente.
3. Integrar fornecedores de pagamento em sandbox, com webhooks verificados, idempotência e reconciliação; só depois habilitar vendas reais.
4. Emitir bilhetes assinados, validar atomicamente no servidor, definir regras de verificação offline e resolução de conflitos.
5. Integrar notificações, relatórios PDF/Excel, atendimento e módulo operacional.
6. Preparar módulo de evento conforme calendário actualizado; testar em viagem experimental; formar equipa e executar lançamento.

Não há estimativa comercial vinculativa: custos e prazos dependem da confirmação do âmbito, equipa, fornecedores e acesso às integrações.

## Estrutura

- dist/index.html: páginas e secções públicas.
- dist/style.css: identidade e adaptação responsiva.
- dist/app.js: traduções, formulários, bilhetes e gestão local.
- dist/sw.js e manifest.webmanifest: PWA.
- dist/assets: fotografias, ícones e gerador QR.

## Terceiros

qrcode-generator 1.4.4, Copyright (c) 2009 Kazuhiko Arase, licença MIT. Aviso original mantido no script. Fontes DM Sans e Playfair Display carregadas pelo Google Fonts. As imagens pertencem aos respectivos titulares e foram fornecidas para este projecto.

## Actualização de cartografia

O esquema SVG e a lista de paragens ilustrativas foram removidos a pedido do utilizador. A secção apresenta cartografia real OpenTopoMap, centrada em -25.98, 32.575, com atribuição de fontes. Não são adicionados marcadores nem percursos do operador sem dados oficiais. Leaflet 1.9.4 está incluído localmente sob licença BSD-2-Clause, conservada em dist/assets/leaflet/LICENSE. Não são pré-carregadas nem guardadas offline as imagens cartográficas externas.

## Manual do administrador — conteúdos

1. Abra /admin ou clique em Admin no rodapé.
2. Entre com a conta ChatGPT proprietária/autorizada. Outras contas não podem publicar.
3. Em Textos, seleccione a secção e o idioma, pesquise o conteúdo e escreva normalmente.
4. Em Imagens e logótipo, carregue JPEG, PNG, WebP ou GIF até 5 MB. Actualize as descrições acessíveis.
5. Veja o rascunho na pré-visualização; pode alternar entre computador e telemóvel.
6. Clique em Publicar alterações. O conteúdo fica guardado no servidor e é consultado por todos os visitantes.
7. Histórico de versões permite recuperar conteúdo anterior como rascunho e voltar a publicá-lo. As versões preservam as referências às imagens.
8. Descartar alterações abandona apenas o rascunho. Terminar sessão usa a autenticação da plataforma.

Os textos são tratados como texto simples e escapados antes de serem apresentados. Não é necessário escrever HTML. O título principal aplica automaticamente o destaque à última linha. Os traçados geográficos continuam a depender de dados oficiais; o CMS não cria rotas.

## Segurança e persistência do CMS

- API de escrita protegida pela identidade autenticada fornecida pela plataforma e pelo email autorizado em variável secreta.
- Validação de origem e cabeçalho de pedido para alterações.
- Limites de tamanho, validação dos formatos de imagens e bloqueio de SVG/HTML.
- R2 para conteúdo partilhado, imagens e versões anteriores; os rascunhos ficam na memória do editor.
- Controlo optimista de revisão e ETag para evitar sobrescrever alterações concorrentes.
- Os dados de CMS não são guardados pelo service worker. Imagens cartográficas externas continuam fora da cache offline.
- O Admin pode alterar o conteúdo de apresentação. Os preços e reservas do simulador anterior mantêm-se locais, sem pagamentos reais.

Testes adicionais: autorização 401/403; bloqueio de pedidos de outra origem; publicação e leitura partilhada; conflito de revisão; histórico; bloqueio de uploads executáveis; persistência de ficheiros. Teste no navegador local: edição, pré-visualização, publicação de texto e recuperação da versão original. O início de sessão real usa a conta do proprietário e precisa da sessão do utilizador na plataforma.
