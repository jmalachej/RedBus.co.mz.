const CONTENT_KEY='cms/content.json';
const MAX_IMAGE=5*1024*1024;
const security={'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'SAMEORIGIN'};
function json(value,status=200){return new Response(JSON.stringify(value),{status,headers:{...security,'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}})}
function identity(request){return {id:request.headers.get('oai-authenticated-user-id')||'',email:(request.headers.get('oai-authenticated-user-email')||'').trim().toLowerCase()}}
function isAdmin(request,env){const u=identity(request);return !!(u.id&&u.email&&env.ADMIN_EMAIL&&u.email===env.ADMIN_EMAIL.trim().toLowerCase())}
function safeWrite(request){return request.headers.get('Origin')===new URL(request.url).origin&&request.headers.get('X-CMS-Request')==='1'}
async function readContent(env){const obj=await env.BUCKET.get(CONTENT_KEY);return obj?{doc:await obj.json(),etag:obj.etag}:{doc:structuredClone(DEFAULT_CONTENT),etag:null}}
function validateContent(input){
 if(!input||typeof input!=='object'||!Number.isInteger(input.revision))throw Error('Documento inválido.');
 const texts={},images={};
 for(const [key,base] of Object.entries(DEFAULT_CONTENT.texts)){
  const item=input.texts?.[key];if(!item||typeof item.pt!=='string'||typeof item.en!=='string'||item.pt.length>6000||item.en.length>6000)throw Error('Texto inválido: '+key);
  texts[key]={pt:item.pt,en:item.en,group:base.group};
 }
 for(const [key,base] of Object.entries(DEFAULT_CONTENT.images)){
  const item=input.images?.[key];
  if(!item||typeof item.src!=='string'||!(item.src===base.src||/^\/media\/[a-f0-9-]{36}\.(jpg|png|webp|gif)$/.test(item.src)))throw Error('Imagem inválida: '+key);
  if(!item.alt||['pt','en'].some(l=>typeof item.alt[l]!=='string'||item.alt[l].length>400))throw Error('Descrição de imagem inválida.');
  images[key]={src:item.src,alt:{pt:item.alt.pt,en:item.alt.en}};
 }
 return {schema:1,revision:input.revision,texts,images};
}
function imageType(b){
 if(b[0]===255&&b[1]===216&&b[2]===255)return ['jpg','image/jpeg'];
 if(b.length>8&&[137,80,78,71,13,10,26,10].every((v,i)=>b[i]===v))return ['png','image/png'];
 if(String.fromCharCode(...b.slice(0,6)).match(/^GIF8[79]a$/))return ['gif','image/gif'];
 if(String.fromCharCode(...b.slice(0,4))==='RIFF'&&String.fromCharCode(...b.slice(8,12))==='WEBP')return ['webp','image/webp'];
 return null;
}
async function boundedBytes(request,limit){
 const length=Number(request.headers.get('content-length')||0);if(length>limit)throw Error('Ficheiro demasiado grande.');
 if(!request.body)return new Uint8Array();const reader=request.body.getReader();let chunks=[],size=0;
 for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>limit){await reader.cancel();throw Error('Ficheiro demasiado grande.')}chunks.push(value)}
 const bytes=new Uint8Array(size);let i=0;for(const c of chunks){bytes.set(c,i);i+=c.length}return bytes;
}
function asset(path,head=false){const a=STATIC_ASSETS[path];if(!a)return new Response('Não encontrado',{status:404,headers:security});const bytes=Uint8Array.from(atob(a.data),c=>c.charCodeAt(0));return new Response(head?null:bytes,{headers:{...security,'Content-Type':a.type,'Cache-Control':/\.(html|js|css|webmanifest)$/.test(path)?'no-cache':'public, max-age=3600'}})}
export default {async fetch(request,env){
 const url=new URL(request.url),path=url.pathname;
 try{
  if(path==='/api/admin/session'){
   if(request.method!=='GET')return json({error:'Método inválido.'},405);
   const user=identity(request);return json({authenticated:!!user.id,admin:isAdmin(request,env),email:user.email||null});
  }
  if(path==='/api/content'&&request.method==='GET')return json((await readContent(env)).doc);
  if(path.startsWith('/api/admin/')){
   if(!identity(request).id)return json({error:'Inicie sessão com a sua conta ChatGPT.'},401);
   if(!isAdmin(request,env))return json({error:'Esta conta não tem autorização de administrador.'},403);
   if(request.method!=='GET'&&!safeWrite(request))return json({error:'Origem do pedido não autorizada.'},403);
   if(path==='/api/admin/defaults'&&request.method==='GET')return json(DEFAULT_CONTENT);
   if(path==='/api/admin/content'&&request.method==='GET')return json((await readContent(env)).doc);
   if(path==='/api/admin/content'&&request.method==='PUT'){
    if(!request.headers.get('content-type')?.includes('application/json'))return json({error:'Formato inválido.'},415);
    let input;try{input=JSON.parse(new TextDecoder().decode(await boundedBytes(request,250000)))}catch{return json({error:'Conteúdo inválido ou demasiado grande.'},400)}
    let next;try{next=validateContent(input)}catch(e){return json({error:e.message},400)}
    const current=await readContent(env);if(next.revision!==current.doc.revision)return json({error:'O conteúdo foi alterado noutra sessão. Recarregue antes de publicar.'},409);
    // Media references must point to uploaded files that actually exist.
    for(const image of Object.values(next.images))if(image.src.startsWith('/media/')&&!await env.BUCKET.head(image.src.slice(1)))return json({error:'Uma imagem já não está disponível. Carregue-a novamente.'},400);
    next.revision++;next.updatedAt=new Date().toISOString();
    const historyKey='cms/history/'+String(9999999999999-Date.now())+'-'+crypto.randomUUID()+'.json';
    await env.BUCKET.put(historyKey,JSON.stringify(current.doc),{httpMetadata:{contentType:'application/json'},customMetadata:{savedAt:next.updatedAt,revision:String(current.doc.revision)}});
    const result=await env.BUCKET.put(CONTENT_KEY,JSON.stringify(next),{onlyIf:current.etag?{etagMatches:current.etag}:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json'},customMetadata:{updatedBy:identity(request).id}});
    if(!result)return json({error:'Outra sessão publicou primeiro. Recarregue antes de tentar novamente.'},409);
    return json(next);
   }
   if(path==='/api/admin/images'&&request.method==='POST'){
    let bytes;try{bytes=await boundedBytes(request,MAX_IMAGE)}catch{return json({error:'A imagem deve ter no máximo 5 MB.'},413)}
    const type=imageType(bytes);if(!type)return json({error:'Use uma imagem JPEG, PNG, WebP ou GIF válida. SVG e outros formatos não são aceites.'},415);
    const key='media/'+crypto.randomUUID()+'.'+type[0];await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:type[1]}});return json({src:'/'+key},201);
   }
   if(path==='/api/admin/history'&&request.method==='GET'){
    const list=await env.BUCKET.list({prefix:'cms/history/',limit:20,include:['customMetadata']});
    return json({versions:list.objects.map(o=>({key:o.key,at:o.customMetadata?.savedAt||o.uploaded,revision:Number(o.customMetadata?.revision||0)}))});
   }
   if(path==='/api/admin/version'&&request.method==='GET'){
    const key=url.searchParams.get('key')||'';if(!/^cms\/history\/\d{13}-[a-f0-9-]{36}\.json$/.test(key))return json({error:'Versão inválida.'},400);
    const version=await env.BUCKET.get(key);return version?json(await version.json()):json({error:'Versão não encontrada.'},404);
   }
   return json({error:'Operação não encontrada.'},404);
  }
  if(path.startsWith('/media/')){
   if(!/^\/media\/[a-f0-9-]{36}\.(jpg|png|webp|gif)$/.test(path))return new Response('Não encontrado',{status:404});
   if(!['GET','HEAD'].includes(request.method))return json({error:'Método inválido.'},405);
   const object=await env.BUCKET.get(path.slice(1));if(!object)return new Response('Não encontrado',{status:404});
   return new Response(request.method==='HEAD'?null:object.body,{headers:{...security,'Content-Type':object.httpMetadata?.contentType||'application/octet-stream','Cache-Control':'public, max-age=31536000, immutable'}});
  }
  if(path.startsWith('/api/'))return json({error:'Não encontrado.'},404);
  if(!['GET','HEAD'].includes(request.method))return json({error:'Método inválido.'},405);
  return asset(path==='/'?'/index.html':path==='/admin'||path==='/admin/'?'/admin.html':path,request.method==='HEAD');
 }catch(e){console.error('CMS request failed',path,e?.name);return json({error:'Não foi possível concluir o pedido. Tente novamente.'},500)}
}};
