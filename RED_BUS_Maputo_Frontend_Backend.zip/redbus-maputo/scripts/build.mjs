import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import path from 'node:path';
const root=process.cwd(),assets={};
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp'};
async function visit(dir){for(const file of await readdir(dir,{withFileTypes:true})){const p=path.join(dir,file.name);if(file.isDirectory())await visit(p);else{const relative='/'+path.relative(path.join(root,'public'),p).split(path.sep).join('/');assets[relative]={type:mime[path.extname(p)]||'text/plain',data:(await readFile(p)).toString('base64')}}}}
await visit(path.join(root,'public'));const defaults=JSON.parse(await readFile('worker/default-content.json','utf8'));const worker=await readFile('worker/index.js','utf8');
await mkdir('dist/server',{recursive:true});await writeFile('dist/server/index.js','const STATIC_ASSETS='+JSON.stringify(assets)+';\nconst DEFAULT_CONTENT='+JSON.stringify(defaults)+';\n'+worker);console.log('Built Worker with '+Object.keys(assets).length+' assets.');
