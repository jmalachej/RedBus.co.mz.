# RED BUS Maputo — entrega do código-fonte

Este pacote contém a versão actual do website e do editor de conteúdos Admin.

## Organização

| Pasta / ficheiro | Conteúdo |
|---|---|
| public/ | Front-end: HTML, CSS, JavaScript, painel Admin, fotografias, mapa e PWA |
| worker/index.js | Back-end: API de conteúdos, autorização de Admin, imagens e histórico |
| worker/default-content.json | Textos e imagens iniciais do CMS |
| scripts/build.mjs | Compila os recursos num Cloudflare Worker |
| scripts/dev-server.mjs | Servidor de desenvolvimento com identidade fictícia para testes locais |
| test/ | Testes do back-end |
| dist/server/index.js | Back-end compilado com os recursos do front-end incluídos |
| .openai/hosting.json | Configuração do alojamento actual |
| README.md | Documentação técnica e manual do administrador |

## Abrir no computador

Instale Node.js 22 ou superior, com npm. Não há dependências npm para instalar.

Na pasta do projecto:

```sh
npm run dev
```

Abra http://localhost:5173 e http://localhost:5173/admin.

O servidor de desenvolvimento usa uma identidade fictícia de Admin e dados em .preview/. Isto serve exclusivamente para testes locais; não deve ser exposto à internet nem usado como servidor comercial.

Para compilar e testar:

```sh
npm run build
npm test
```

## Publicação

O código publicado usa Cloudflare Workers, armazenamento R2 ligado como BUCKET e a variável secreta ADMIN_EMAIL com o email da conta administrativa autorizada. O alojamento actual fornece a autenticação ChatGPT e os cabeçalhos de identidade validados. O endereço de Admin é /admin.

A API não implementa um sistema autónomo de palavras-passe. Para migrar para outro fornecedor, será necessário integrar autenticação equivalente, proteger os cabeçalhos de identidade contra falsificação e configurar o armazenamento. Não basta carregar o front-end num alojamento estático para obter o CMS funcional.

O identificador em .openai/hosting.json corresponde ao website existente. Não o reutilize para criar outro projecto independente.

## Estado da entrega

O CMS permite editar os textos principais em português e inglês, substituir imagens/logótipo, pré-visualizar, publicar e recuperar versões. As alterações publicadas ficam guardadas no servidor.

A venda de bilhetes continua em modo de demonstração. Reservas, lotação e validação de bilhetes do simulador são locais; não há pagamentos reais, contas de passageiros ou sincronização de reservas entre dispositivos. Esta entrega não significa que todos os requisitos comerciais do PDF estejam implementados.

Não são incluídos credenciais, tokens, palavras-passe, dados de teste locais, histórico Git nem cópias do armazenamento remoto. Os conteúdos iniciais estão em worker/default-content.json; edições ou imagens carregadas posteriormente no CMS ficam no armazenamento do website e exigem exportação própria se for feita uma migração.

As fotografias fornecidas e as licenças dos componentes de terceiros acompanham o front-end. O mapa usa cartografia real OpenTopoMap; as imagens cartográficas são obtidas pela internet e não são incluídas no ZIP.
