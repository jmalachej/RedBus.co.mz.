// Published content is shared by all visitors; drafts are visible only in the editor preview.
function cmsSafeHtml(text,key){const lines=String(text).split('\n').map(s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));if(['heroTitle','photoGreeting'].includes(key)&&lines.length>1)lines[lines.length-1]='<em>'+lines[lines.length-1]+'</em>';return lines.join('<br>')}
let cmsDocument=null;
function applyCms(doc){
 if(!doc?.texts||!doc?.images)return;cmsDocument=doc;
 document.querySelectorAll('[data-t]').forEach(el=>{const key=el.dataset.t,item=doc.texts[key];if(item){el.dataset.pt=cmsSafeHtml(item.pt,key);en[key]=cmsSafeHtml(item.en,key)}});
 document.querySelectorAll('[data-cms-image]').forEach(img=>{const slot=doc.images[img.dataset.cmsImage];if(!slot)return;img.hidden=!slot.src;if(slot.src)img.src=slot.src;img.alt=slot.alt?.[lang]||'';if(img.dataset.cmsImage==='logo')img.parentElement.querySelector('svg').style.display=slot.src?'none':''});
 document.querySelectorAll('[data-photo]').forEach(button=>{const src=button.querySelector('img')?.src;if(src)button.dataset.cmsSrc=src});translate();
}
// Synchronise published content after changing the visitor language.
document.getElementById('language')?.addEventListener('click',()=>{if(cmsDocument)document.querySelectorAll('[data-cms-image]').forEach(img=>{img.alt=cmsDocument.images[img.dataset.cmsImage]?.alt?.[lang]||''})});
if(new URLSearchParams(location.search).has('cms-preview')){
 window.addEventListener('message',event=>{if(event.origin!==location.origin||event.source!==window.parent||event.data?.type!=='redbus-cms-preview')return;applyCms(event.data.content)});
 window.parent.postMessage({type:'redbus-cms-ready'},location.origin);
}else fetch('/api/content',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(applyCms).catch(()=>{});
